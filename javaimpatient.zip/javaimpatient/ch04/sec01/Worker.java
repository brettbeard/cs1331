package ch04.sec01;

public class Worker {
    public void work() { 
        for (int i = 0; i < 100; i++) System.out.println("Working"); 
    }
}