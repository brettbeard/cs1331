@SuppressWarnings("module")
module ch15.sec08 {
   requires com.horstmann.greetsvc;
   uses com.horstmann.greetsvc.GreeterService;
}
